import profile
import MyNotepad

profile.run("MyNotepad.RunApp()")